package exemples.dinerphilosophes;

import java.util.Random;
import java.util.concurrent.Semaphore;

/**
 * 
 * @author Nicolas
 * @version 1.0
 */
public class Philo extends Thread {

	int id;
	
	Semaphore table;
	Semaphore gauche;
	Semaphore droite;
	
	Random alea;
	
	/**
	 * Constructeur
	 * @param i numero du philosophe
	 */
	public Philo(int i, Semaphore t, Semaphore g, Semaphore d) {
		super("Philo"+i);
		this.id = i;
		this.table = t;
		this.gauche = g;
		this.droite = d;
		this.alea = new Random(System.currentTimeMillis());
	}
	
	/**
	 * Penser
	 */
	public void penser() {
		System.out.println(this.getName()+" pense");
		long t = alea.nextInt(3000) + 1000;
		try {
			sleep(t);
		}
		catch(InterruptedException ie) {
			System.err.println("Erreur : penser() pour "+this.getName());
			ie.printStackTrace();
		}
	}

	/**
	 * Manger
	 */
	public void manger() {
		System.out.println(this.getName()+" veut manger");
		try {
			table.acquire(); // demande 1 acces "table"
			gauche.acquire(); // demande fourchette gauche
			droite.acquire(); // demande fourchette droite
			System.out.println(this.getName()+" mange");
			long t = alea.nextInt(3000) + 1000;
			sleep(t);
			System.out.println(this.getName()+" a fini de manger");
			droite.release(); // repose fourchette droite
			gauche.release(); // repose fourchette gauche
			table.release(); // rend 1 acces "table"
		}
		catch(InterruptedException ie) {
			System.err.println("Erreur : manger() pour "+this.getName());
			ie.printStackTrace();
		}
	}

	/**
	 * Activite d'un philosophe
	 */
	public void run() {
		while(true) {
			this.penser();
			this.manger();
		}	
	}
	
}
