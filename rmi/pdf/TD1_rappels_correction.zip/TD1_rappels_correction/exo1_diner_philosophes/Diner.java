package exemples.dinerphilosophes;

import java.util.concurrent.Semaphore;

/**
 * Solution mise en place : 
 * 
 * 4 semaphores : 1 "par fourchette", pour proteger l'acces a une fourchette,
 * initialisation a 1.
 * 
 * 1 semaphore pour proteger l'acces a la table, initialisation a 4, 
 * (permet d'eviter l'inter-blocage : chaque philosophe a pris une fourchette).
 * 
 * @author Nicolas
 * @version 1.0
 */
public class Diner {

	/**
	 * Programme principal
	 * @param args
	 */
	public static void main(String[] args) {
		
		int N = 5;
		
		if(args.length > 0) N = Integer.parseInt(args[0]); 
		
		Semaphore table = new Semaphore(4);
		Semaphore [] fourchettes = new Semaphore [N];
		Philo [] philo = new Philo [N];
		
		// creation des semaphores correspondant aux fourchettes
		for(int i=0; i<N; i++)
			fourchettes[i] = new Semaphore(1);
		
		// creation des threads correspondant aux philosophes
		for(int i=0; i<N; i++)
			philo[i] = new Philo(i, table, fourchettes[i], fourchettes[(i+1)%N]);
		
		// demarrage des threads philo
		for(int i=0; i<N; i++)
			philo[i].start();
		
	}

}

/*
Exemple d'execution :
Philo0 pense
Philo2 pense
Philo1 pense
Philo3 pense
Philo4 pense
Philo4 veut manger
Philo4 mange
Philo0 veut manger
Philo3 veut manger
Philo1 veut manger
Philo1 mange
Philo2 veut manger
Philo4 a fini de manger
Philo3 mange
Philo4 pense
Philo1 a fini de manger
Philo1 pense
Philo0 mange
Philo4 veut manger
Philo1 veut manger
Philo3 a fini de manger
Philo3 pense
Philo2 mange
Philo0 a fini de manger
Philo0 pense
Philo4 mange
...

On verifie que 2 philosophes voisins ne mangent pas en meme temps,
qu'il n'y a pas de famine (chaque philosophe arrive a manger), 
ni d'inter-blocage.

*/
