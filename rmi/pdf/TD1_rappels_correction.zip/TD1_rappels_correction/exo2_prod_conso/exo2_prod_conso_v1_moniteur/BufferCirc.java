
/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * Buffer circulaire
 *
 * @author Nicolas
 * @version 1.0
 */
public class BufferCirc {

	private Object[] tampon;
	private int taille;
	private int prem, der, nbObj;


	public BufferCirc (int t) {
		taille = t;
		tampon = new Object[taille];
		prem = 0;
		der = 0;
		nbObj = 0;
	}


	synchronized public void depose(Object o) {
		while (nbObj == taille) {
			try { 
				System.out.println(Thread.currentThread().getName()+" attend");
				this.wait();
				System.out.println(Thread.currentThread().getName()+" reveille");
			}
			catch (InterruptedException e) {}
		}
		tampon[der] = o;
		der = (der + 1) % taille;
		nbObj = nbObj + 1;
		System.out.println (Thread.currentThread().getName() + " a depose " + (Integer)o);
		this.notifyAll();
	}


	synchronized public Object preleve() {
		while (nbObj == 0) {
			try { 
				System.out.println(Thread.currentThread().getName()+" attend");
				this.wait();
				System.out.println(Thread.currentThread().getName()+" reveille");
			}
			catch (InterruptedException e) {}
		}
		Object o = tampon[prem];
		tampon[prem] = null;
		prem = (prem + 1) % taille;
		nbObj = nbObj - 1;
		System.out.println (Thread.currentThread().getName() + " a preleve " + (Integer)o);
		this.notifyAll();
		return (o);
	}

}


/*
Pour eviter les blocages, il faut utiliser ici "notifyAll()" au lieu de "notify()".
*/

