
/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * Consommateur
 *
 * @author Nicolas
 * @version 1.0
 */
public class Consommateur implements Runnable {
	
	private BufferCirc buffer;
	

	public Consommateur(BufferCirc b) {
	buffer = b;
	}
	
	public void run() {
		Integer val;
		while (true) {
			val = (Integer) buffer.preleve();
			System.out.println (Thread.currentThread().getName() + " a preleve " + val);
			try {
				Thread.sleep((int)(Math.random()*1000));
			}
			catch (InterruptedException e) {}
		}
	}

}
