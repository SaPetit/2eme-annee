
/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * Producteur
 *
 * @author Nicolas
 * @version 1.0
 */
public class Producteur implements Runnable {

	private BufferCirc buffer;
	private int val;


	public Producteur(BufferCirc b) {
		buffer = b;
	}

	public void run() {
		while (true) {
			buffer.depose(new Integer(val));
			System.out.println (Thread.currentThread().getName() +	" a depose " + val);
			val++;
		}
	}

}
