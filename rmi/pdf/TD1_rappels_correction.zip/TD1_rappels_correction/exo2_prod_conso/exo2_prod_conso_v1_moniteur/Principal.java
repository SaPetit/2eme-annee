import java.util.ArrayList;

/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * Programme principal (main)
 *
 * @author Nicolas
 * @version 1.0
 */
public class Principal {

	/**
	 * Main
	 * @param tailleBuffer Taille du buffer (taille du tableau)
	 * @param nbreProducteurs Nombre de producteurs
	 * @param nbreConsommateurs Nombre de consommateurs
	 */
	public static void main (String[] args) {

		if(args.length<3)
			System.err.println("Usage: java Principal tailleBuffer nbreProducteurs nbreConsommateurs\n");
		else
		{	
			int tailleBuffer = 0;
			int nbProd = 0;
			int nbCons = 0;
			BufferCirc b = null;
			Producteur p = null;
			Consommateur c = null;
			Thread t = null;
			ArrayList<Thread> listeProd = null;
			ArrayList<Thread> listeCons = null;

			try {
				tailleBuffer = Integer.parseInt(args[0]);
				nbProd = Integer.parseInt(args[1]);
				nbCons = Integer.parseInt(args[2]);
				
				listeProd = new ArrayList<Thread>();
				listeCons = new ArrayList<Thread>();

				b = new BufferCirc(tailleBuffer);
				
				for(int i=0; i<nbProd; i++) {
					p = new Producteur(b);
					t = new Thread(p);
					t.setName("P"+(i+1));
					listeProd.add(t);
				}

				for(int i=0; i<nbCons; i++) {
					c = new Consommateur(b);
					t = new Thread(c);
					t.setName("C"+(i+1));
					listeCons.add(t);
				}

				for(Thread th : listeProd) {
					th.start();
				}

				for(Thread th : listeCons) {
					th.start();
				}
				
			}
			catch(NumberFormatException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}

}


/*
Exemple d'execution :
C2 attend
P1 a depose 0
C1 a preleve 0
P1 a depose 1
P1 attend
C2 reveille
C2 a preleve 1
P1 reveille
P1 a depose 2
P1 attend
C2 a preleve 2
P1 reveille
P1 a depose 3
P1 attend
C1 a preleve 3
P1 reveille
P1 a depose 4
P1 attend
C1 a preleve 4
P1 reveille
P1 a depose 5
P1 attend
C2 a preleve 5
P1 reveille
P1 a depose 6
P1 attend
C1 a preleve 6
P1 reveille
P1 a depose 7
P1 attend
C2 a preleve 7
P1 reveille
P1 a depose 8
P1 attend
C1 a preleve 8
P1 reveille
P1 a depose 9
P1 attend
C2 a preleve 9
P1 reveille
P1 a depose 10
P1 attend
C1 a preleve 10
P1 reveille
P1 a depose 11
P1 attend
C1 a preleve 11
P1 reveille
P1 a depose 12
P1 attend
C2 a preleve 12
P1 reveille
P1 a depose 13
P1 attend
C1 a preleve 13
P1 reveille
P1 a depose 14
P1 attend
C2 a preleve 14
P1 reveille
P1 a depose 15
P1 attend
C1 a preleve 15
P1 reveille
P1 a depose 16
P1 attend
C2 a preleve 16
P1 reveille
P1 a depose 17
P1 attend
P1 reveille
C1 a preleve 17
P1 a depose 18
P1 attend
C2 a preleve 18
P1 reveille
P1 a depose 19
P1 attend
C2 a preleve 19
P1 reveille
P1 a depose 20
P1 attend
P1 reveille
C1 a preleve 20
P1 a depose 21
P1 attend
C2 a preleve 21
P1 reveille
P1 a depose 22
P1 attend
P1 reveille
C1 a preleve 22
P1 a depose 23
P1 attend
C2 a preleve 23
P1 reveille
P1 a depose 24
P1 attend
P1 reveille
C1 a preleve 24
P1 a depose 25
P1 attend
P1 reveille
C1 a preleve 25
P1 a depose 26
P1 attend
C2 a preleve 26
P1 reveille
P1 a depose 27
P1 attend
P1 reveille
C1 a preleve 27
P1 a depose 28
P1 attend
C2 a preleve 28
P1 reveille
P1 a depose 29
C1 a preleve 29
P1 a depose 30
P1 attend
C2 a preleve 30
P1 reveille
P1 a depose 31
P1 attend
P1 reveille
C1 a preleve 31
P1 a depose 32
P1 attend
P1 reveille
C1 a preleve 32
P1 a depose 33
P1 attend
...
*/
