


public class Consommateur implements Runnable {
	
	private BufferCircLock buffer;
	
	
	public Consommateur(BufferCircLock b) {
	buffer = b;
	}

	
	public void run() {
	Integer val;
	while (true) {
	try {
        val = (Integer) buffer.preleve();
	Thread.sleep((int)(Math.random()*1000));
	}
	catch (InterruptedException e) {}
	}
	}

} // fin classe Consommateur

