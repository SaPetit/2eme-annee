import java.util.concurrent.locks.*;

//prod/cons : version avec un ReentrantLock et deux Condition


class BufferCircLock {

 Lock verrou = new ReentrantLock();
 Condition pasPlein = verrou.newCondition();
 Condition pasVide = verrou.newCondition();

 int taille;
 int depot;
 int retrait;
 int nbElems;
 Object [] items;


 public BufferCircLock(int t) {
  verrou = new ReentrantLock();
  pasPlein = verrou.newCondition();
  pasVide = verrou.newCondition();
  taille = t;
  depot = 0;
  retrait = 0;
  nbElems = 0;
  items = new Object[taille];
 }

 public void depose(Object obj) throws InterruptedException {
   verrou.lock();
   while(nbElems == items.length) {
     System.out.println(Thread.currentThread().getName()+" attend");
     pasPlein.await();
     System.out.println(Thread.currentThread().getName()+" reveille");
   }
   items[depot] = obj;
   depot = (depot + 1) % items.length;
   nbElems++;
   System.out.println (Thread.currentThread().getName() + " a depose " + (Integer)obj);
   this.affiche();
   pasVide.signal();
   verrou.unlock();
 }

 public Object preleve() throws InterruptedException {
   verrou.lock();
   while(nbElems == 0) {
     System.out.println(Thread.currentThread().getName()+" attend");
     pasVide.await();
     System.out.println(Thread.currentThread().getName()+" reveille");
   }
   Object obj = items[retrait];
   items[retrait] = null;
   retrait = (retrait + 1) % items.length;
   nbElems--;
   System.out.println (Thread.currentThread().getName() + " a preleve " + (Integer)obj);
   this.affiche();
   pasPlein.signal();
   verrou.unlock();
   return obj;
 }


 private void affiche() {
  for(Object o: this.items) {
    if(o != null) System.out.print(" "+(Integer)o);
  }
  System.out.print("\n");
 }
}

