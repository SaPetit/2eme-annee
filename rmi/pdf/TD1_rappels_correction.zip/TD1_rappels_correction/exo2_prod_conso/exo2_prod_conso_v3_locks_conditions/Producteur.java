
public class Producteur implements Runnable {

	private BufferCircLock buffer;
	private int val;


	public Producteur(BufferCircLock b) {
		buffer = b;
	}


	public void run() {
		while (true) {
                        try {
			  buffer.depose(new Integer(val));
			  val++;
			  Thread.sleep((int)(Math.random()*1000));
			}
			catch (InterruptedException e) {}
		}
	}

} // fin classe Producteur
