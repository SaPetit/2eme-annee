
import java.util.ArrayList;


public class Principal {

	public static void main (String[] args) {

		if(args.length<3)
			System.err.println("Usage: java Principal tailleBuffer nbProducteurs nbConsommateurs\n");
		else
		{	
			int tailleBuffer = 0;
			int nbProd = 0;
			int nbCons = 0;
			BufferCircLock b = null;
			Producteur p = null;
			Consommateur c = null;
			Thread t = null;
			ArrayList<Thread> listeProd = null;
			ArrayList<Thread> listeCons = null;

			try {
				tailleBuffer = Integer.parseInt(args[0]);
				nbProd = Integer.parseInt(args[1]);
				nbCons = Integer.parseInt(args[2]);
				
				listeProd = new ArrayList<Thread>();
				listeCons = new ArrayList<Thread>();

				b = new BufferCircLock(tailleBuffer);
				
				for(int i=0; i<nbProd; i++) {
					p = new Producteur(b);
					t = new Thread(p);
					t.setName("P"+(i+1));
					listeProd.add(t);
				}

				for(int i=0; i<nbCons; i++) {
					c = new Consommateur(b);
					t = new Thread(c);
					t.setName("C"+(i+1));
					listeCons.add(t);
				}

				for(Thread th : listeProd) {
					th.start();
				}

				for(Thread th : listeCons) {
					th.start();
				}
				
			}
			catch(NumberFormatException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}

}


/*
Exemple d'execution :
java Principal 2 2 2
P1 a depose 0
 0
P2 a depose 0
 0 0
C1 a preleve 0
 0
C2 a preleve 0

P1 a depose 1
 1
P1 a depose 2
 1 2
P2 attend
P1 attend
C1 a preleve 1
 2
P2 reveille
P2 a depose 1
 1 2
C1 a preleve 2
 1
P1 reveille
P1 a depose 3
 1 3
C2 a preleve 1
 3
P1 a depose 4
 4 3
C1 a preleve 3
 4
C2 a preleve 4

P2 a depose 2
 2
C2 a preleve 2

P1 a depose 5
 5
P2 a depose 3
 5 3
C2 a preleve 5
 3
C1 a preleve 3

P1 a depose 6
 6
C2 a preleve 6

C1 attend
P2 a depose 4
 4
C1 reveille
C1 a preleve 4

P1 a depose 7
 7
C2 a preleve 7

C2 attend
P2 a depose 5
 5
C2 reveille
C2 a preleve 5

P2 a depose 6
 6
C2 a preleve 6

C1 attend
P1 a depose 8
 8
C1 reveille
C1 a preleve 8

C2 attend
P2 a depose 7
 7
C2 reveille
C2 a preleve 7

C1 attend
P1 a depose 9
 9
C1 reveille
C1 a preleve 9

C2 attend
P2 a depose 8
 8
C2 reveille
C2 a preleve 8

C1 attend
C2 attend
P1 a depose 10
 10
C1 reveille
C1 a preleve 10

P2 a depose 9
 9
C2 reveille
C2 a preleve 9
...
*/
