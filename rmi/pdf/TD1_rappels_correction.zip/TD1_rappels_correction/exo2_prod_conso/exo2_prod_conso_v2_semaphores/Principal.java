import java.util.ArrayList;
import java.util.concurrent.Semaphore;

/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * version avec uniquement des semaphores
 *
 * Programme principal (main)
 *
 * @author Nicolas
 * @version 1.0
 */
public class Principal {

	/**
	 * Main
	 * @param tailleBuffer Taille du buffer (taille du tableau)
	 * @param nbreProducteurs Nombre de producteurs
	 * @param nbreConsommateurs Nombre de consommateurs
	 */
	public static void main (String[] args) {

		if(args.length<3)
			System.err.println("Usage: java Principal tailleBuffer nbProducteurs nbConsommateurs\n");
		else
		{	
			int tailleBuffer = 0;
			int nbProd = 0;
			int nbCons = 0;
			BufferCirc b = null;
			Producteur p = null;
			Consommateur c = null;
			Thread t = null;
			ArrayList<Thread> listeProd = null;
			ArrayList<Thread> listeCons = null;

			Semaphore mutexDepose = new Semaphore(1);
			Semaphore mutexPreleve = new Semaphore(1);
			Semaphore pasPlein = null; //sera initialise plus tard a "tailleBuffer"
			Semaphore pasVide = new Semaphore(0);

			try {
				tailleBuffer = Integer.parseInt(args[0]);
				nbProd = Integer.parseInt(args[1]);
				nbCons = Integer.parseInt(args[2]);
				
				pasPlein = new Semaphore(tailleBuffer);
				
				listeProd = new ArrayList<Thread>();
				listeCons = new ArrayList<Thread>();

				b = new BufferCirc(tailleBuffer);
				
				for(int i=0; i<nbProd; i++) {
					p = new Producteur(b, pasPlein, pasVide, mutexDepose);
					t = new Thread(p);
					t.setName("P"+(i+1));
					listeProd.add(t);
				}

				for(int i=0; i<nbCons; i++) {
					c = new Consommateur(b, pasPlein, pasVide, mutexPreleve);
					t = new Thread(c);
					t.setName("C"+(i+1));
					listeCons.add(t);
				}

				for(Thread th : listeProd) {
					th.start();
				}

				for(Thread th : listeCons) {
					th.start();
				}
				
			}
			catch(NumberFormatException e) {
				System.err.println(e.getMessage());
				e.printStackTrace();
			}
		}
	}

}


/*
Exemple d'execution :
java Principal 2 2 2 
P1 a depose 0
0 null 
P2 a depose 0
null 0 
C1 a preleve 0
null 0 
P1 a depose 1
1 0 
C2 a preleve 0
1 null 
P2 a depose 1
1 1 
C2 a preleve 1
null 1 
P1 a depose 2
2 1 
C2 a preleve 1
2 null 
P2 a depose 2
2 2 
C2 a preleve 2
null 2 
P1 a depose 3
3 2 
C1 a preleve 2
3 null 
P2 a depose 3
3 3 
C2 a preleve 3
null 3 
P1 a depose 4
4 3 
C2 a preleve 3
4 null 
P2 a depose 4
4 4 
C1 a preleve 4
null 4 
P1 a depose 5
5 4 
C2 a preleve 4
5 null 
P2 a depose 5
5 5 
C1 a preleve 5
null 5 
P1 a depose 6
6 5 
C2 a preleve 5
6 null 
P2 a depose 6
6 6 
C1 a preleve 6
null 6 
P1 a depose 7
7 6 
C2 a preleve 6
7 null 
P2 a depose 7
7 7 
...
*/
