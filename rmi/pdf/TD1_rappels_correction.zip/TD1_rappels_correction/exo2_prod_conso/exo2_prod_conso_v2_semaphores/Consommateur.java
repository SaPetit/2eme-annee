import java.util.concurrent.Semaphore;

/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * version avec uniquement des semaphores
 *
 * Consommateur
 *
 * @author Nicolas
 * @version 1.0
 */
public class Consommateur implements Runnable {
	
	private BufferCirc buffer;
	private Semaphore pasPlein;
	private Semaphore pasVide;
	private Semaphore mutexPreleve;

	
	public Consommateur(BufferCirc b, Semaphore pasPlein, Semaphore pasVide, Semaphore mutexPreleve) {
		this.buffer = b;
		this.pasPlein = pasPlein;
		this.pasVide = pasVide;
		this.mutexPreleve = mutexPreleve;
	}

	
	public void run() {
		Integer val;
		while (true) {
			try {
				//si buffer vide alors attendre
				pasVide.acquire();
				mutexPreleve.acquire(); // un seul prelevement a la fois	
				val = (Integer) buffer.preleve();
				mutexPreleve.release();
				pasPlein.release();
				Thread.sleep((int)(Math.random()*1000));
			}
			catch (InterruptedException e) {}
		}
	}

} // fin classe Consommateur

