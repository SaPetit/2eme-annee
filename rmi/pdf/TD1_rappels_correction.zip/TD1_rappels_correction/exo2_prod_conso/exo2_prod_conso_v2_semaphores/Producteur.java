import java.util.concurrent.Semaphore;

/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * version avec uniquement des semaphores
 *
 * Producteur
 *
 * @author Nicolas
 * @version 1.0
 */
public class Producteur implements Runnable {

	private BufferCirc buffer;
	private int val;
	private Semaphore pasPlein;
	private Semaphore pasVide;
	private Semaphore mutexDepose;


	public Producteur(BufferCirc b, Semaphore pasPlein, Semaphore pasVide, Semaphore mutexDepose) {
		this.buffer = b;
		this.pasPlein = pasPlein;
		this.pasVide = pasVide;
		this.mutexDepose = mutexDepose;
	}


	public void run() {
		while (true) {
			try {
				//si le buffer est plein, il faut attendre avant de deposer
				pasPlein.acquire();
				mutexDepose.acquire(); // un seul depot a la fois
				buffer.depose(new Integer(val));
				val++;
				mutexDepose.release();
				//reveil eventuel consommateur en attente
				pasVide.release();
				//Thread.sleep((int)(Math.random()*100));
			}
			catch (InterruptedException e) {}
		}
	}

} // fin classe Producteur
