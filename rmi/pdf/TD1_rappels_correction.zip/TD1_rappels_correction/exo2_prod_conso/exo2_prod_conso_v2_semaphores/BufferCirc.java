
/**
 * implementation du producteur-consommateur avec un buffer circulaire
 *
 * version avec uniquement des semaphores
 *
 * Buffer circulaire
 *
 * @author Nicolas
 * @version 1.0
 */
public class BufferCirc {

	private Object[] tampon;
	private int taille;
	private int prem, der, nbObj;


	public BufferCirc (int t) {
		taille = t;
		tampon = new Object[taille];
		prem = 0;
		der = 0;
		nbObj = 0;
	}


	public void depose(Object o) {
		tampon[der] = o;
		der = (der + 1) % taille;
		nbObj = nbObj + 1;
		System.out.println (Thread.currentThread().getName() + " a depose " + (Integer)o);
		this.afficher();
	}


	public Object preleve() {
		Object o = tampon[prem];
		tampon[prem] = null;
		prem = (prem + 1) % taille;
		nbObj = nbObj - 1;
		System.out.println (Thread.currentThread().getName() + " a preleve " + (Integer)o);
		this.afficher();
		return (o);
	}

	public void afficher() {
		for(int i=0; i<taille; i++) {
			System.out.print(tampon[i]+ " ");
		}
		System.out.print("\n");
	}

} // fin class BufferCirc


