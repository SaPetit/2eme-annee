package pidist;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.StringTokenizer;

/**
 * Calcul de PI en distribue (plusieurs machines)
 * Programme d'un esclave
 * 
 * @author nicolas
 * @version 0.1
 */
public class PIesclave {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			if(args.length<1) {
				System.err.println("Usage : java pidist.PIesclave port");
				System.exit(1);
			}
			
			int port = Integer.parseInt(args[0]);
			int len = 50;
			InetAddress IPreponse = null;
			
			//reception d'un message de demande de calcul
			DatagramSocket ds = new DatagramSocket(port);
			byte[] buffer = new byte[len];
			DatagramPacket incomingPacket = new DatagramPacket(buffer, buffer.length);
			ds.receive(incomingPacket);
			String s = new String(incomingPacket.getData());
			IPreponse = incomingPacket.getAddress();
			System.out.println("Reception de "+s+" venant de "+ IPreponse + " at port " + incomingPacket.getPort());		
			ds.close();
			
			System.out.println(s);
			
			StringTokenizer st = new StringTokenizer(s,":");
			int k = Integer.parseInt(st.nextToken());
			int n = Integer.parseInt(st.nextToken());
			int nb = Integer.parseInt(st.nextToken());
			int portmaitre = Integer.parseInt(st.nextToken());
			
			// realisation du calcul
			
			// resultat de la somme partielle
			double sommePartielle = 0;
			
			// indice de depart de la somme
			int istart = (int) (1 + ((double)((k-1)*n) / nb));
			
			// indice de fin
			int iend = (int) (k * ((double)n / nb));
			
			System.out.println("CalculPi "+k+" : i de "+istart+" a "+iend);
			
			// calcul de la somme partielle
			for(int i=istart; i<=iend; i++)
				sommePartielle += 4 / (n * (1 + (((i-0.5)/n) * ((i-0.5)/n))));
			
			System.out.println("Resultat : "+sommePartielle);
			
			//envoi du resultat
			DatagramSocket theSocket = new DatagramSocket();
			String theLine = ""+sommePartielle;				
			byte[] data = theLine.getBytes();
			DatagramPacket theOutput = new DatagramPacket(data, data.length, IPreponse, portmaitre);
			theSocket.send(theOutput);
			System.out.println("Envoi du resultat effectue a "+IPreponse+" "+portmaitre);
			theSocket.close();
		}
		catch (UnknownHostException e) {
			System.err.println(e);
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println(e);
			e.printStackTrace();
		}
	}

}
