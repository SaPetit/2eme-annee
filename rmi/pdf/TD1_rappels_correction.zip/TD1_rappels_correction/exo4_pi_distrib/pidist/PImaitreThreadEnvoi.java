package pidist;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.StringTokenizer;

/**
 * Calcul de PI en distribue (plusieurs machines)
 * 
 * Thread qui envoie une demande de calcul a un esclave
 * 
 * @author nicolas
 * @version 0.1
 */
public class PImaitreThreadEnvoi extends Thread{

	int i;
	int n;
	int nb;
	int portLocal;
	int len;
	String IPesclave;
	int portEsclave;
	
	
	public PImaitreThreadEnvoi(int i, int n, int nb, int len, int portlocal, String IPport) {
		this.i= i;
		this.n = n;
		this.nb = nb;
		this.len = len;
		this.portLocal = portlocal;
		StringTokenizer st = new StringTokenizer(IPport,":");
		this.IPesclave = st.nextToken();
		this.portEsclave = Integer.parseInt(st.nextToken());
	}

	public void run() {
		try {
			//envoi message de demande de calcul
			InetAddress receiver = InetAddress.getByName(IPesclave);
			DatagramSocket theSocket = new DatagramSocket();
			String theLine = i+":"+n+":"+nb+":"+portLocal+":";				
			byte[] data = theLine.getBytes();
			DatagramPacket theOutput = new DatagramPacket(data, data.length, receiver, portEsclave);
			System.out.println("Thread "+i+" ("+portLocal+") a envoye une demande de calcul a "+IPesclave+" "+portEsclave);
			theSocket.send(theOutput);
			theSocket.close();
		} catch (SocketException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}	
	}
}
