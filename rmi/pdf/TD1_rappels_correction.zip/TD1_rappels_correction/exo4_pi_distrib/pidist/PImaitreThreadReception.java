package pidist;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.StringTokenizer;

/**
 * Calcul de PI en distribue (plusieurs machines)
 * 
 * Thread qui attend la resultat d'un esclave
 * 
 * @author nicolas
 * @version 0.1
 */
public class PImaitreThreadReception extends Thread{

	int i;
	int portLocal;
	int len;
	String IPesclave;
	int portEsclave;
	
	
	public PImaitreThreadReception(int i, int len, int portlocal, String IPport) {
		this.i= i;
		this.len = len;
		this.portLocal = portlocal;
		StringTokenizer st = new StringTokenizer(IPport,":");
		this.IPesclave = st.nextToken();
		this.portEsclave = Integer.parseInt(st.nextToken());
	}

	public void run() {
		try {			
			//attendre reponse de l'esclave
			DatagramSocket ds = new DatagramSocket(portLocal);
			byte[] buffer = new byte[len];
			DatagramPacket incomingPacket = new DatagramPacket(buffer, buffer.length);
			ds.receive(incomingPacket);
			System.out.println("Thread "+i+" ("+portLocal+") attend le resultat de "+IPesclave+" "+portEsclave);
			String s = new String(incomingPacket.getData());
			System.out.println("Thread "+i+" ("+portLocal+") a recu "+s+" de "+incomingPacket.getAddress() + " at port " + incomingPacket.getPort());
			//mise a jour tab resultat
			double res = Double.parseDouble(s);
			PImaitre.tabResultats[i] = res;
			ds.close();
		} catch (SocketException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}	
	}
}
