package pidist;

import java.util.ArrayList;

/**
 * Calcul de PI en distribue (plusieurs machines)
 * Programme du maitre
 * 
 * @author nicolas
 * @version 0.1
 */
public class PImaitre {

	public static double tabResultats[];


	/**
	 * Programme principal (du maitre)
	 * @param args[0] : n, indique la precision du calcul
	 * @param args[1] : nb (N dans la formule), nombre d'esclaves utilises
	 * @param args[1] : portinit Numero de port de base pour les port utilises par les threads du maitre (reception resultats)
	 * @param args[...] : "IP:port" de chaque esclave
	 */
	public static void main(String[] args) {
		if(args.length<3) {
			System.err.println("Usage : java pidist.PImaitre n N portinit IP:port...\nn=precision\nN=nbre threads\nListe IP:port des esclaves");
			System.exit(1);
		}

		int n = Integer.parseInt(args[0]);
		int nb = Integer.parseInt(args[1]);			
		int portinit = Integer.parseInt(args[2]);

		if(nb > n) {
			System.err.println("Attention, il faut nb (2eme arg) << n (1er arg)");
			System.exit(1);
		}

		String tabEsclaves[] = new String[nb+1];
		int p = 0;
		int len = 50;

		for(int l=3; l<args.length; l++) {
			tabEsclaves[p]=args[l];
			p = p + 1;
		}

		for(int g=0; g<nb; g++)	System.out.println(tabEsclaves[g]);

		tabResultats = new double[nb+1];

		/* Liste des Threads crees */
		ArrayList<Thread> lesThreads = new ArrayList<Thread>();
		PImaitreThreadReception th = null;

		/* Creation et lancement des treads de reception des resultats */
		for(int i=1; i<=nb; i++) {
			// i est utilise comme identificateur
			th = new PImaitreThreadReception(i, len, portinit+i, tabEsclaves[i-1]);
			lesThreads.add(th);
			th.start();
		}

		/* Creation et lancement des threads d'envoi demandes calcul */
		for(int i=1; i<=nb; i++) {
			(new PImaitreThreadEnvoi(i, n, nb, len, portinit+i, tabEsclaves[i-1])).start();
		}
				
		/* On attend qu'ils finissent tous */
		for(Thread t : lesThreads) {
			try {
				t.join();
			}
			catch(InterruptedException ie) {
				System.err.println(ie.getMessage());
				ie.printStackTrace();
			}
		}

		/* Calcul et affichage du resultat final */
		double result = 0;
		for(int i=0; i<=nb; i++) result = result + tabResultats[i];
		System.out.println("\nPI ~ "+result);
	}

}
