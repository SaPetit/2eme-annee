
javac pidist/*.java

#pour tester sur la meme machine :

java pidist.PImaitre 1000 3 4000 127.0.0.1:6001 127.0.0.1:6002 127.0.0.1:6003

java pidist.PIesclave 6001

java pidist.PIesclave 6002

java pidist.PIesclave 6003


#pour tester sur differentes machines, il suffit d'indiquer 
#les adresses IP des machines utilisees a la place des "127.0.0.1"

