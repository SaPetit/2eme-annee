
#Se placer dans le dossier CONTENANT le dossier "exojavarmi" et ce fichier readme.



#Compilation :
javac exojavarmi/hotel/*.java

#Generation des souches :
rmic exojavarmi.hotel.ChaineHotels


# fichier texte "security.policy" contenant la politique de securite retenue
# (ici on autorise tout... dangereux !)



#Utilisation de l'application :


#On suppose que le registre utilise le port par defaut 1099


#Sur la machine "serveur" :

#Lancement du registre rmi :
rmiregistry


#Lancement du programme serveur :
java -cp . -Djava.security.policy=./exojavarmi/hotel/security.policy -Djava.rmi.server.codebase=file:/./  exojavarmi.hotel.ChaineHotelsServeurRMI



#Sur la machine "client" :

#Lancement du programme client :
java -cp . -Djava.security.policy=./exojavarmi/hotel/security.policy -Djava.rmi.server.codebase=file:/./  exojavarmi.hotel.ChaineHotelsClientRMI 127.0.0.1 1099

