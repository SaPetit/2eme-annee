package tchatrmi;

import java.io.Serializable;
import java.util.Calendar;


/**
 * Tchat en Java RMI
 * @author Toto
 * @version 1.0
 */
public class Message implements Serializable
{
	private static final long serialVersionUID = -9090058837598137252L;
	
	// L'emeteur du message.
    private String emetteur;
    
    // Le contenu du message.
    private String message;
    
    // Heure du message.
    private Calendar heure;



    /**
     * <p>
     * Constructeur : Message vide.
     * </p>
     * <p>
     * </p>
     */
    public Message()
    {
        this("", "");
        heure = Calendar.getInstance();
    }


    /**
     * 
     */
    public Message(String emetteur, String message)
    {
        setEmetteur(emetteur);
        setMessage(message);
        heure = Calendar.getInstance();
    }


    /**
     *
     */
    public String getEmetteur()
    {
        return emetteur;
    }


    /**
     *
     */
    private void setEmetteur(String emetteur)
    {
        this.emetteur = emetteur;
    }


    /**
     *
     */
    public String getMessage()
    {
        return message;
    }


    /**
     *
     */
    private void setMessage(String message)
    {
        this.message = message;
    }


    /**
     *
     */
    public String getHeure()
    {
        return heure.get(Calendar.HOUR_OF_DAY) + ":" + heure.get(Calendar.MINUTE);
    }


    /**
     *
     */
    public String toString()
    {
        return getEmetteur() + "> " + getMessage();
    }


    /**
     *
     */
    public String toString2()
    {
        return getEmetteur() + "> (" + heure.get(Calendar.HOUR_OF_DAY) + ":" + heure.get(Calendar.MINUTE) + ") "
                + getMessage();
    }
    
}
