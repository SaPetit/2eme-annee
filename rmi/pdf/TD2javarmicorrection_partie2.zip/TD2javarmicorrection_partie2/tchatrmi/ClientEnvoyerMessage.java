package tchatrmi;


/**
 * Tchat en Java RMI
 * @author Toto
 * @version 1.0
 */
public class ClientEnvoyerMessage implements Runnable {

	private IHM ihm;
	private String nomClient;
	private ServeurInterface serveurChat;

	
	/**
	 * Constructeur
	 * @param nom Pseudo du client
	 * @param ihm IHM de l'application Chat
	 * @param ps Fluw d'ecriture sur la socket client 
	 */
	public ClientEnvoyerMessage(String nom, IHM ihm, ServeurInterface serveur) {
		this.ihm = ihm;
		this.nomClient = nom;
		this.serveurChat = serveur;
	}

	
	/**
	 * Activite du thread.
	 * Recuperation d'un message tape dans l'IHM puis envoi qu serveur
	 */
	public void run () {
		String texte = "";
		Message m = null;
		try {
			while(true) {
				texte = nomClient.concat(" : ").concat(ihm.getNextMessageToSend());
				m = new Message(nomClient, texte);
				System.out.println("envoi en cours de " +  texte + "...");
				serveurChat.envoyerMessage(m);
			}
		}
		catch (Exception ex) {
			ex.printStackTrace ();
		}
	}

} // fin classe ClientEnvoyerMessage
