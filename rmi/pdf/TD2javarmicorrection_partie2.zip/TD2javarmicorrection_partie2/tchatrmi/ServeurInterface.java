package tchatrmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 * Tchat en Java RMI
 * @author Toto
 * @version 1.0
 */
public interface ServeurInterface extends Remote {
	
	public void enregistrer(String url) throws RemoteException;
	
	public void desenregistrer(String url) throws RemoteException;

	public void envoyerMessage(Message m) throws RemoteException;

	public void envoyerMessageUnique(Message m, String utilisateur) throws RemoteException;

	public ArrayList<String> getUtilisateurs() throws RemoteException;
	
}
