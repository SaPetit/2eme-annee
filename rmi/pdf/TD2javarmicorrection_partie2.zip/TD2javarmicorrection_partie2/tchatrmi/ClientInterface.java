package tchatrmi;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Tchat en Java RMI
 * @author Toto
 * @version 1.0
 */
public interface ClientInterface extends Remote {

	public void afficherMessage(Message m) throws RemoteException;
	
	public String getUtilisateur() throws RemoteException;

}
