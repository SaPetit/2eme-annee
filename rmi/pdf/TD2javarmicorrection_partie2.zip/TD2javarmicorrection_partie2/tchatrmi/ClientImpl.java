package tchatrmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * Tchat en Java RMI
 * @author Toto
 * @version 1.0
 */
public class ClientImpl extends UnicastRemoteObject implements ClientInterface {

	private static final long serialVersionUID = -3279574511232523144L;
	
    private String utilisateur;
    private IHM ihm;
    
	
	public ClientImpl(String pseudo, IHM ihm) throws RemoteException {
		super();
		this.utilisateur = pseudo;
		this.ihm = ihm;
	}

	public void afficherMessage(Message m) throws RemoteException {
		System.out.println ("... reception de : " + m.toString2());
		ihm.writeMessage(m.getEmetteur()+" : "+m.getMessage());	
	}

	public String getUtilisateur() throws RemoteException {
		return utilisateur;
	}

}
