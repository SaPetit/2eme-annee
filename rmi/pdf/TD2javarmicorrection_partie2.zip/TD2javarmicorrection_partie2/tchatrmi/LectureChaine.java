package tchatrmi;

import java.io.*; 

/**
 * Tchat en Java RMI
 * @author Toto
 * @version 1.0
 */
public class LectureChaine { 
    public static String lireChaine(){ 
	String inputLine = null; 
	try { 
	    BufferedReader buffer =  new BufferedReader ( new InputStreamReader(System.in)); 
	    inputLine = buffer.readLine(); 
	    if( inputLine.length() == 0) return null; 
	} catch (IOException e) { 
	System.out.println("IOException: " + e); 
	} 
	return inputLine; 
    } 


    public static void main(String[] args) {
	//LectureChaine l = new LectureChaine();
	System.out.println("Entrer x");
	int x = new Integer( LectureChaine.lireChaine()) + 5;
	System.out.println("Entrer y");
	String y = LectureChaine.lireChaine();
	System.out.println("echo : " +x + y);
    }
}