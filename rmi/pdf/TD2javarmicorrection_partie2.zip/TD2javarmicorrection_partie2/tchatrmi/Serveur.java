package tchatrmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;


/**
 * Tchat en Java RMI
 * @author Toto
 * @version 1.0
 */
public class Serveur { 
    
    private static int DEFAULT_REGISTRY_PORT = 1099;


	/**
	 * Constructeur par dfaut
	 */
	public Serveur() {
	}


	/**
	 * Programme principal
	 */
	public static void main(String[] args) {
		
		ServeurImpl serveurChat;
		
		int port = -1;

		if(args.length != 1) {
			System.out.println("Usage: java tp2.Serveur Port");
			System.out.println("Utilisation du port par dfaut ("+DEFAULT_REGISTRY_PORT+")");
			port = DEFAULT_REGISTRY_PORT;
		}
		else { 
			try {
				port = Integer.parseInt(args[0]);
			}
			catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				System.exit(1);
			}
		}
		
		try {
			serveurChat = new ServeurImpl();
			System.setSecurityManager(new RMISecurityManager()); 
			Naming.rebind("rmi://localhost:"+port+"/Serveur", serveurChat);
			System.out.println("Serveur : OK");
		}
		catch (RemoteException e) {
			System.err.println("Serveur : erreur\n"+e.getMessage());
			e.printStackTrace();
		} 
		catch (MalformedURLException e) {
			System.err.println("Serveur : erreur\n"+e.getMessage());
			e.printStackTrace();
		}
	}
    
    
    
}
