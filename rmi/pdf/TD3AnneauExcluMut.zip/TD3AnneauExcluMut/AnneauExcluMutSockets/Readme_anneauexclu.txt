#Exclusion mutuelle sur un anneau a jeton


#Se placer dans le dossier contenant le dossier "anneauexclu"


#Compilation 

javac anneauexclu/*.java


#Lancement serveur central

java -cp . anneauexclu.ServeurCentral 5000 100


#Lancement de 3 sites (le site 1 cree le jeton)
# arguments :
# args[0] adresse IP du serveur central
# args[1] numero de port du serveur central
# args[2] numero de port d'ecoute du serveur local
# args[3] adresse IP du successeur
# args[4] numero de port du successeur
# args[5] booleen indiquant si le jeton doit etre cree

java -cp . anneauexclu.ProgrammeSite 127.0.0.1 5000 5001 127.0.0.1 5002 true

java -cp . anneauexclu.ProgrammeSite 127.0.0.1 5000 5002 127.0.0.1 5003 false

java -cp . anneauexclu.ProgrammeSite 120.0.0.1 5000 5003 127.0.0.1 5001 false


