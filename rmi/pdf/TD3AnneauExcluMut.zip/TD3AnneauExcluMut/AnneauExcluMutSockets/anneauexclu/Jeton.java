package anneauexclu;

import java.io.Serializable;

/**
 * @author nicolas
 *
 */
public class Jeton implements Serializable {

	private static final long serialVersionUID = 80608973554383338L;

	public Jeton() {
	}
	
	public String toString() {
		return "token";
	}
}
